
library(tidyverse)

# Make sure you're in the R project that you set up last week. 
# You'll need to edit the next two lines. 
*MISSING* <- read_csv("*MISSING") 
*MISSING_2* <- read_csv("*MISSING*") 

# The challenge last week was to adapt the code to be something like the following
boxplot(phones$usage ~ phones$phone_type)
phones %>% ggplot(aes(x = phone_type, y = usage)) + geom_violin()

# Scripts can pretty hard to read and work with if we always have everything on a single line. So...
phones %>% 
  ggplot() + 
  geom_violin(aes(x = phone_type, y = usage))

# The plot doesn't look at clear and meaningful as it might, so we can add labels
boxplot(phones$usage ~ phones$phone_type, 
        xlab = "what is this label doing?", ylab = "what is this for?", main = "What am I?", col = "green") # Edit the text

phones %>% 
  ggplot() + 
  geom_violin(aes(x = phone_type, y = usage)) +
  labs(title="Use the main title", x = "X axis label",  y= "Y axis label") + # Edit the text
 theme_bw()

money %>% 
  ggplot() + 
  geom_density(aes(x = salary, y = ..count.., fill = family_position), alpha=.4) +
  scale_fill_manual(values = c("darkgreen", "darkblue","red","orange")) +
  theme_classic()

# Final exercise. Convert all the phone usage data into z scores with scale. Look at the result. What is the largest and smallest z score?
usage_z <-scale(*MISSING*)
usage_z_sorted <- sort(usage_z, decreasing = FALSE) # If you had to guess, what does sort() do?
print(usage_z_sorted) # This displays the object from the previous line. Does this help work out sort()?
